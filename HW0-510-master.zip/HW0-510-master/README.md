# HW0-510
For the software engineering course.


* Basic Course Setup
  * Stack Overflow
  * Mattermost - Uploaded Photo and updated name
  * Moodle - Uploaded Photo
  * Github
    * Made a private Repo and added TA and Instructor as Collaborator - https://github.ncsu.edu/rjain27/HW0-510
  * Asking a Question, Answering a Question on Stack Over Flow Teams
    * Asked Question - https://stackoverflow.com/c/ncsu/questions/738/740#740
    * Answered Question - https://stackoverflow.com/c/ncsu/questions/746/748?noredirect=1#comment726_748
  * Opunit checks - pass 100 % - Please refer the screenshot link that shows all the 15 checks pass. The command is "opunit profile CSC-DevOps/profile:510.yml" : https://media.github.ncsu.edu/user/14795/files/719a2c80-d0b8-11e9-9e74-f447b68e6838
* Engineering Basics workshop
  * Please refer to the screenshot which shows that all levels of git branching tutorial are done : https://media.github.ncsu.edu/user/14795/files/6ba44b80-d0b8-11e9-9045-f7a0c78df73a
     * Introduction Sequence - Done
     * Ramping Up - Done
     * Moving Work Around - Done
     * A Mixed Bag - Done
     * For extra credit, complete "Advanced Topics". - Done 
  * Shells questions 
     * Please refer to the screenshot showing that all the commands gave correct output and the "$ opunit verify local" command passed
       https://media.github.ncsu.edu/user/14795/files/6e06a580-d0b8-11e9-81d0-912c2599f5c8
     * File with all the commands that I executed with explanation : https://github.ncsu.edu/rjain27/HW0-510/files/317/shell_command.txt
  * Create a GitHub issue - https://github.ncsu.edu/rjain27/HW0-510/issues?q=is%3Aissue+is%3Aclosed
* Screencast video link - https://drive.google.com/drive/folders/1Nzo0mbrErYmrgocZ-A7aQTysOSK8b4dj?usp=sharing
